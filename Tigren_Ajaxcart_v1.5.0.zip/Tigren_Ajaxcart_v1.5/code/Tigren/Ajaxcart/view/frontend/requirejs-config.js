var config = {
    map: {
        '*': {
            'tigren/swatchRenderer': 'Tigren_Ajaxcart/js/swatch-renderer',
            'sidebar': 'Tigren_Ajaxcart/js/sidebar',
            'tigren/ajaxToCart': 'Tigren_Ajaxcart/js/ajax-to-cart',
            shoppingCart1: 'Tigren_Ajaxcart/js/shopping-cart',
            qtyButton: 'Tigren_Ajaxcart/js/qty-button',
        }
    }
};

