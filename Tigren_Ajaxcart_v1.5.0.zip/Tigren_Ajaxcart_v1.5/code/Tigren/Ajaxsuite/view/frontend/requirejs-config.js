/**
 * @copyright Copyright (c) 2017 www.tigren.com
 */

var config = {
    map: {
        '*': {
            'tigren/ajaxsuite': 'Tigren_Ajaxsuite/js/ajax-suite'
        }
    }
};
